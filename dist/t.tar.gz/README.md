# About the dist folder
After building the dist version of your project, the generated files are stored in this folder. You should keep it under version control.
